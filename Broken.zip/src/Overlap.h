#ifndef OVERLAP_H
#define OVERLAP_H

#include <SFML/Graphics.hpp>

bool overlap(sf::Sprite& sprite1, sf::Sprite& sprite2);

#endif